﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Ports;
using System.Threading;

using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SerialPort _sp = new SerialPort();
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            readSMS();
        }
        private void readSMS()
        {
           
            _sp.PortName = "COM11";
            _sp.BaudRate = 115200;
            _sp.Parity = Parity.None;
            _sp.DataBits = 8;
            _sp.StopBits = StopBits.One;
            _sp.Handshake = Handshake.XOnXOff;

            //  sp.m

            _sp.DtrEnable = true;
            _sp.RtsEnable = true;
            _sp.NewLine = Environment.NewLine;

            _sp.Open();

            _sp.Write("AT" + System.Environment.NewLine);
            Thread.Sleep(1000);

            _sp.WriteLine("AT+CMGF=1" + System.Environment.NewLine);
            Thread.Sleep(1000);
            _sp.WriteLine("AT+CMGL=\"ALL\"\r" + System.Environment.NewLine);//("AT+CMGL=\"rec Unread\"\r");
            Thread.Sleep(3000);

          // MessageBox.Show(_sp.ReadExisting());

            Regex r = new Regex(@"\+CMGL: (\d+),""(.+)"",""(.+)"",(.*),""(.+)""\r\n(.+)\r\n");
            Match m = r.Match(_sp.ReadExisting());

            while (m.Success)
            {
                string a = m.Groups[1].Value;
                string b = m.Groups[2].Value;
                string c = m.Groups[3].Value;
                string d = m.Groups[4].Value;
                string ee = m.Groups[5].Value;
                string f = m.Groups[6].Value;

                ListViewItem item = new ListViewItem(new string[] { a,b,c,d,ee,f });
                listView1.Items.Add(item);
                m = m.NextMatch();

            }


        }
        
        private void btnSend_Click(object sender, EventArgs e)
        {
            SerialPort sp = new SerialPort();
            try {
               
                sp.PortName = txtPort.Text;
                sp.BaudRate = 115200;
                sp.Parity = Parity.None;
                sp.DataBits = 8;

              //  sp.read
                sp.Open();

                sp.WriteLine("AT" + Environment.NewLine);
                Thread.Sleep(100);

                sp.WriteLine("AT+CMGF=1" + Environment.NewLine);
                Thread.Sleep(100);

                sp.WriteLine("AT+CMGS=\""+ txtPhone.Text +"\"" + Environment.NewLine);
                Thread.Sleep(100);

                sp.WriteLine(txtMessage.Text + Environment.NewLine);
                Thread.Sleep(100);

                sp.Write(new byte[] { 26 }, 0, 1);
                Thread.Sleep(100);

                var response = sp.ReadExisting();
                if (response.Contains("ERROR"))

                MessageBox.Show("Send Failed","Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Message has been sent", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                sp.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

        }

      
    }
}
